class TimeConversion:
    @staticmethod
    def unixepoch2jd(unixepoch: int) -> float:
        """
        Compute the Julian day (JD) of the given unixepoch (POSIX time)

        :param unixepoch: Unixepoch (POSIX time). units: seconds [s]
        :return: Julian day (JD). units: JD 
        """
        return unixepoch/86400 + 2440587.5

    @staticmethod
    def unixepoch2j2000(unixepoch: int) -> float:
        """
        Compute the Julian year (J2000) of the given unixepoch (POSIX time)

        :param unixepoch: Unixepoch (POSIX time). units: seconds [s]
        :return: Julian year (J2000). units: J2000
        """
        return unixepoch/86400 - 10957.5

    @staticmethod
    def unixepoch2j2000d5(unixepoch: int) -> float:
        """
        Compute date in fractions of days since 1 january 2000 00:00, of the given unixepoch (POSIX time)

        :param unixepoch: Unixepoch (POSIX time). units: seconds [s]
        :return: Date (fraction of days) since 1 january 2000 00:00
        """
        return TimeConversion.unixepoch2j2000(unixepoch) + 0.5

    